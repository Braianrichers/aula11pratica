package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText edt1;
    EditText edt2;
    EditText edtres;
    Button btnsoma;
    Button btnsub;
    Button btnmult;
    Button btndiv;
    Button btnporc;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt1 = (EditText) findViewById(R.id.editTextvalor1);
        edt2 = (EditText) findViewById(R.id.editTextvalor2);
        edtres = (EditText) findViewById(R.id.editTextresultado);
        btnsoma = (Button) findViewById(R.id.buttonsoma);
        btnsub = (Button) findViewById(R.id.buttonsub);
        btnmult = (Button) findViewById(R.id.buttonmult);
        btndiv = (Button) findViewById(R.id.buttondiv);
        btnporc = (Button) findViewById(R.id.buttonporc);


        btnsoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1;
                Double v2;
                Double res;
                v1 = Double.parseDouble( edt1.getText().toString());
                v2 = Double.parseDouble( edt2.getText().toString());
                res= v1+v2;
                edtres.setText(res.toString());

            }
        });

        btnsub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1;
                Double v2;
                Double res;
                v1 = Double.parseDouble( edt1.getText().toString());
                v2 = Double.parseDouble( edt2.getText().toString());
                res= v1-v2;
                edtres.setText(res.toString());
            }
        });

        btnmult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1;
                Double v2;
                Double res;
                v1 = Double.parseDouble( edt1.getText().toString());
                v2 = Double.parseDouble( edt2.getText().toString());
                res= v1*v2;
                edtres.setText(res.toString());
            }
        });

        btndiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1;
                Double v2;
                Double res;
                v1 = Double.parseDouble( edt1.getText().toString());
                v2 = Double.parseDouble( edt2.getText().toString());
                res= v1/v2;
                edtres.setText(res.toString());
            }
        });

        btnporc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double v1;
                Double v2;
                Double res;
                v1 = Double.parseDouble( edt1.getText().toString());
                v2 = Double.parseDouble( edt2.getText().toString());
                res= v1/100*v2;
                edtres.setText(res.toString());
            }
        });
    }
}
