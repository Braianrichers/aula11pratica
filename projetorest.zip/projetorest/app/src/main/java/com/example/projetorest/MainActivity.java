package com.example.projetorest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText ed1;
    EditText ed2;
    EditText ed3;
    Button btn1;
    EditText rest1;
    EditText rest2;
    EditText rest3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1 = (EditText) findViewById(R.id.edt_consumo);
        ed2 = (EditText) findViewById(R.id.edt_couvert_artistico);
        ed3 = (EditText) findViewById(R.id.edt_div);
        btn1 = (Button) findViewById(R.id.bt_calcular);
        rest1 = (EditText) findViewById(R.id.edt_servico);
        rest2 = (EditText) findViewById(R.id.edt_conta_total);
        rest3 = (EditText) findViewById(R.id.edt_valor_pessoa);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double v3;

                Double r1;
                Double r2;
                Double r3;

                v1 = Double.parseDouble(ed1.getText().toString());
                v2 = Double.parseDouble(ed2.getText().toString());
                v3 = Double.parseDouble(ed3.getText().toString());

                r1= (v1+v2)/v3/100*10;
                r2= (v1+v2)+r1;
                r3= (v1+v2+r1)/v3;

                rest1.setText(r1.toString());
                rest2.setText(r2.toString());
                rest3.setText(r3.toString());
            }
        });


            }
    }


